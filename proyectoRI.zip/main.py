from launcher.launcher import launcher

if __name__ == "__main__":
    launcher()