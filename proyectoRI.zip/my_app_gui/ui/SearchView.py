"""
SearchView defines the main user interface components:
- A search screen with an entry field and search button.
- A result screen that displays document matches with score and preview.
"""

import customtkinter as ctk
from typing import Callable
from models.Search import SearchResult
import os
import subprocess
import platform

class SearchView(ctk.CTkFrame):
    def __init__(self, master: ctk.CTk, on_search: Callable[[str, str], None]):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self.on_search = on_search
        self._build_header() 
        self._build_search_screen()
        self.doc_paths = {} 

    def _build_header(self):
        """Construye el encabezado con título arriba e icono debajo"""
        header_frame = ctk.CTkFrame(self, fg_color="transparent", height=100)
        header_frame.pack(fill="x", pady=(10, 0))
        header_frame.pack_propagate(False)
        
        center_container = ctk.CTkFrame(header_frame, fg_color="transparent")
        center_container.pack(expand=True)
        
        self.title_label = ctk.CTkLabel(
            center_container,
            text="Motor de Búsqueda EPN",
            font=("Century Gothic", 40, "bold"),
            text_color="#901B8A"
        )
        self.title_label.pack(pady=(0, 5))
        
        self.logo_label = ctk.CTkLabel(
            center_container,
            text="(◕‿◕)",
            font=("Arial", 50)
        )
        self.logo_label.pack()

    def _build_search_screen(self):
        # Configuración del tema
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")  
        
        self.search_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.search_frame.pack(fill="x", padx=20, pady=10)
        
        # --- Selector de Modelo ---
        self.model_combo = ctk.CTkComboBox(
            self.search_frame,
            values=["BM25", "TF-IDF", "Binario"],
            width=200,
            state="normal", 
            font=("Arial", 12)
        )
        self.model_combo.set("Seleccionar Modelo")
        self.model_combo.pack(side="left", padx=(0, 10))
        # ---------------------------------

        self.query_entry = ctk.CTkEntry(
            self.search_frame,
            placeholder_text="Buscar en documentos...",
            width=400,
            height=40,
            corner_radius=20,
            font=("Arial", 14)
        )
        self.query_entry.pack(side="left", expand=True, fill="x", padx=(0, 10))
        
        self.search_button = ctk.CTkButton(
            self.search_frame,
            text="Buscar",
            command=self._handle_search,
            height=40,
            width=100,
            corner_radius=20,
            font=("Arial", 14, "bold"),
            fg_color="#1a73e8",
            hover_color="#4581cb"
        )
        self.search_button.pack(side="left")

        self.results_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.results_frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))

    def _handle_search(self):
        query = self.query_entry.get()
        model_selection = self.model_combo.get()
        
        if not query:
            self._show_message("Ingrese una búsqueda.")
            return

        model_code = "bm25" 
        if "TF-IDF" in model_selection:
            model_code = "tf-idf"
        elif "Binario" in model_selection:
            model_code = "binary"
            
        self._clear_results()
        self.on_search(query, model_code)

    def _clear_results(self):
        for widget in self.results_frame.winfo_children():
            widget.destroy()

    def _show_message(self, message: str):
        label = ctk.CTkLabel(
            self.results_frame,
            text=message,
            font=("Arial", 14),
            text_color="gray"
        )
        label.pack(pady=20)

    def show_results(self, results: list[SearchResult]):
        self._clear_results()
        self.doc_paths = {}
        
        if not results:
            self._show_message("No Se Encontraron Resultados.")
            return
            
        for res in results:
            doc_id = res.doc_id
            self.doc_paths[doc_id] = doc_id  
            self._add_result_card(
                title=os.path.basename(doc_id),
                score=res.score,
                doc_path=doc_id
            )

    def _add_result_card(self, title: str, score: float, doc_path: str):
        card = ctk.CTkFrame(
            self.results_frame,
            corner_radius=15,
            border_width=1,
            border_color="#000000"
            
        )
        card.pack(fill="x", pady=5)
        
        card.bind("<Button-1>", lambda e, path=doc_path: self._open_document(path))
        card.configure(cursor="hand2")
        
        content_frame = ctk.CTkFrame(card, fg_color="transparent")
        content_frame.pack(fill="x", padx=15, pady=10)

        title_label = ctk.CTkLabel(
            content_frame,
            text=title,
            font=("Arial", 30, "bold"),
            anchor="w",
            wraplength=600
        )
        title_label.pack(fill="x", padx=15, pady=(10, 0))
        title_label.bind("<Button-1>", lambda e, path=doc_path: self._open_document(path))
        
        #path_label = ctk.CTkLabel(
        #    content_frame,
        #    text=doc_path,
        #    font=("Arial", 10),
        #    text_color="gray",
        #    anchor="w",
        #    wraplength=600
        #)
        #path_label.pack(fill="x", pady=(2, 0))
        #path_label.bind("<Button-1>", lambda e, path=doc_path: self._open_document(path))

        score_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
        score_frame.pack(fill="x", pady=(15, 0))
        
        score_label = ctk.CTkLabel(
            score_frame,
            text=f"Relevancia: {score:.4f}",
            font=("Italic", 15),
            text_color="royal blue"
        )
        score_label.pack(side="left")

        ctk.CTkFrame(card, height=1, fg_color="#99e0f6").pack(fill="x", padx=15, pady=(5, 0))

    def _open_document(self, filepath: str):
        try:
            if platform.system() == "Windows":
                os.startfile(filepath)
            elif platform.system() == "Darwin":
                subprocess.run(["open", filepath], check=True)
            else:
                subprocess.run(["xdg-open", filepath], check=True)
        except Exception as e:
            print(f"Error al abrir el documento: {e}")