# Server address
HOST = "localhost"
PORT = 9000

THEME = "dark"  # 'light' o 'dark'