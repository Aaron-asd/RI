"""
Controller for the GUI application.
Handles interaction between the user interface and the search service.
"""

from models.Search import SearchResult
from config import HOST, PORT
from network.TcpClient import TcpClient

class SearchController:
    def __init__(self, host: str = HOST, port: int = PORT):
        self.host = host
        self.port = port

    def send_query(self, query: str, model_type: str) -> list[SearchResult]:

        raw_results = TcpClient(self.host, self.port).query(query, model_type)
        
        return [SearchResult(doc_id=doc, score=score) for doc, score in raw_results]
