# Proyecto Sitema Recuperación de Información 
## Nombres: Stiven Saldaña y Aaron Yumancela

# Importante 
Usar la versión 3.12.8 de phyton para que sea compatible con las librerias

# Para ejecutar
py setup_project.py \
.venv/Scripts/activate \ 
pip install -r requirements.txt

# Comando para ejecutar el programa
py main.py 

# Librerías instaladas
nltk \
watchdog \
python-dotenv \

# Pruebas de Métricas 

# 1. Preparacion

1.  Ingresa a la carpeta
    ```bash
    bin/evaluate_system
    ```
2.  **Ingresa datos de prueba** en la funcion `GROUND_TRUTH` inserta datos de prueba.

3.  **Ejecuta el servicio de indexación:**
    Ejecuta este comando.
    ```bash
    python -m search_engine.bin.index_service
    ```
    Debes esperar a que salga este mensaje `[Watcher] Index updated`

## 2. Detener el Servicio

1.  Una vez que veas aparezca el mensaje presiona Control para detener la ejecucion

## 3. Ejecución

1.  Y despues ejecuta este comando
    ```bash
    python -m search_engine.bin.evaluate_system
    ```
    Para inicar la prueba
